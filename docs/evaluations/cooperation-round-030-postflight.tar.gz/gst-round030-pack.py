import pathlib,json,gzip,hashlib,collections,shutil,datetime,subprocess
root=pathlib.Path('.');tmp=pathlib.Path('/tmp/gst-round030');out=root/'docs/evaluations/cooperation-round-030-development';h=lambda b:hashlib.sha256(b).hexdigest()
d=json.loads(pathlib.Path(str(tmp)+'.json').read_bytes());v=json.loads(pathlib.Path(str(tmp)+'.verified.json').read_bytes());assert d['complete'] and v['complete'] and d['executions']==v['executions']==3072
files={}
for ext in ['.json','.journal.ndjson']:
 raw=pathlib.Path(str(tmp)+ext).read_bytes();p=pathlib.Path(str(out)+ext+'.gz');p.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(p.read_bytes())==raw;files[p.name]=h(p.read_bytes())
for ext in ['.publication.json','.verified.json','.batches.ndjson']:
 p=pathlib.Path(str(out)+ext);shutil.copyfile(str(tmp)+ext,p);files[p.name]=h(p.read_bytes())
pairs=collections.defaultdict(dict)
for x in d['records']:
 f=x['result']['game']['fixture'];key=(x['mode'],x['style'],f['seed'],f['reversed'],f['currentSide']);pairs[key][x['variant']]=x['result']
resource={};changes=[]
def score(r):return .5 if r['game']['winnerPolicy'] is None else int(r['game']['winnerPolicy']=='current')
for key,p in pairs.items():
 c,s=p['control'],p['single']
 if not c['point']:continue
 pt=c['point'];z=resource.setdefault(key[0],{'pairedPoints':0,'extraAttackAccepted':0,'extraAttackRejected':0,'extraAttackNominalMana':0,'controlSameAttackWithin5s':0,'controlNeverSameAttack':0,'directEvidence':collections.Counter(),'selectedOwnAfterPoint':{v:collections.Counter() for v in ['control','single']}})
 z['pairedPoints']+=1;z['extraAttackAccepted']+=s['point']['accepted'] is True;z['extraAttackRejected']+=s['point']['accepted'] is False;z['extraAttackNominalMana']+=pt['before']['skillCost'];z['directEvidence'][pt['event']['kind']]+=1
 delay=c['resources']['firstSameAttackDelayMs'];z['controlSameAttackWithin5s']+=delay is not None and delay<=5000;z['controlNeverSameAttack']+=delay is None
 for variant,r in p.items():
  a=z['selectedOwnAfterPoint'][variant]
  for k in ['aliveMs','trueNameMs','turns','trueNameTurns','trueNameBonusGross','incomingAllyManaGross','turnGainGross','acceptedSkillMana','acceptedSkills','rejectedSkills','attackFailures']:a[k]+=r['resources'][k]
  a['aliveAtEnd']+=r['resources']['aliveAtEnd'] is True
 if score(c)!=score(s):changes.append({'fixture':c['game']['fixture'],'style':key[1],'controlScore':score(c),'singleScore':score(s),'pointAt':pt['at'],'receiptKind':pt['event']['kind'],'action':pt['action'],'cost':pt['before']['skillCost']})
manifest={'kind':'gst-single-direct-check-diagnostic-results','sourceRef':'7a8eb17df8692a4fc87e59c1810b0d9425d9a0ef','corePolicySourceRef':'c598fda20052bf46fc73d2b7affe0d0b5442159e','phase':'development-diagnostic','executions':3072,'terminated':3072-sum(b['unfinished'] for m in v['modes'].values() for b in m.values()),'summary':v,'fingerprint':d['fingerprint'],'policySHA256':h(json.dumps({k:s for k,s in d['sourceHashes'].items() if k.startswith('src/')},sort_keys=True,separators=(',',':')).encode()),'sourceHashes':d['sourceHashes'],'auxiliarySourceHashes':d['auxiliarySourceHashes'],'design':d['design'],'settings':d['settings'],'designOptionsSHA256':h(json.dumps({'design':d['design'],'settings':d['settings'],'variants':d['variants'],'selectedPublicPlayer':d['selectedPublicPlayer']},sort_keys=True,separators=(',',':')).encode()),'resourcesByMode':resource,'scoreChanges':changes,'resourceInterpretation':'Paired pre-intervention eligible p1 only; own postpoint resource totals and target delays are mechanisms/descriptive endpoints, not evidence of overall/team policy promotion. No subgroup selection. This diagnostic has no main baseline arm.','promotionEvidence':False,'holdoutUsed':False,'actualHumanMatches':0,'tests':622,'rulesTests':547,'serverTests':75,'typecheck':'4_packages_passed','builds':'server_client_Worker_passed','supervisorRegression':'4_passed','CI':'https://github.com/Cjsarts0509/Guardian-Spirits-Tactics/actions/runs/38720781717','browser':'https://github.com/Cjsarts0509/Guardian-Spirits-Tactics/actions/runs/38720781843','files':files}
rows=[json.loads(l) for l in pathlib.Path(str(tmp)+'.batches.ndjson').read_text().splitlines()];assert len(rows)==32 and sum(x['newGames'] for x in rows)==3072 and all(x['publicationVerified'] and x['newGames']==96 for x in rows)
manifest.update(batchFailures=0,duplicateExecutions=0,batches=32,unitFixturesExcluded=True,checkpointsExcludedAsDuplicates=True)
pathlib.Path(str(out)+'-results.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
audit=json.loads(pathlib.Path('docs/evaluations/cooperation-round-028-cumulative-audit.json').read_text());hist=json.loads(pathlib.Path('docs/evaluations/cooperation-round-025-historical-corpus-audit.json').read_text())
used=[(x['start'],x['start']+x['seeds']) for x in hist['datasets']]+[(x['start'],x['start']+x['count']) for x in audit['newDatasets']]+[(142000,142032)]
assert all(a[1]<=b[0] or b[1]<=a[0] for i,a in enumerate(used) for b in used[i+1:]);assert all(end<=121000 or start>=121016 for start,end in used);assert all(end<=143000 or start>=143008 for start,end in used)
audit.update(verifiedExecutions=38976,terminated=38976-2-sum(b['unfinished'] for m in v['modes'].values() for b in m.values()),unfinished=2+sum(b['unfinished'] for m in v['modes'].values() for b in m.values()),primaryDatasets=25,previousAuditSHA256=h(pathlib.Path('docs/evaluations/cooperation-round-028-cumulative-audit.json').read_bytes()),currentRoundExecutions=3072,currentResumeResearchExecutions=5376,newResearchExecutions=7680,unusedConditionalDevelopment={'start':143000,'count':8})
audit['newDatasets'].append({'round':30,'phase':'development-diagnostic','sourceRef':manifest['sourceRef'],'start':142000,'count':32,'executions':3072,'rawSHA256':h(pathlib.Path(str(tmp)+'.json').read_bytes()),'rawGzSHA256':files[out.name+'.json.gz'],'unfinished':3072-manifest['terminated']})
pathlib.Path('docs/evaluations/cooperation-round-030-cumulative-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'summary':v,'resources':resource,'policySHA256':manifest['policySHA256'],'designOptionsSHA256':manifest['designOptionsSHA256'],'files':files},ensure_ascii=False,indent=2))
