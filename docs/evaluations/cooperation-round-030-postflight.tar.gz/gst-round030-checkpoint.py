import pathlib,json,gzip,shutil,datetime,sys,hashlib
base=pathlib.Path('/tmp/gst-round030');v=json.loads(base.with_suffix('.verified.json').read_text());n=int(sys.argv[1]);assert v['executions']==n and not v['complete']
out=pathlib.Path('docs/evaluations/cooperation-round-030-checkpoint'+str(n))
for ext in ['.json','.journal.ndjson']:
 raw=pathlib.Path(str(base)+ext).read_bytes()
 dest=pathlib.Path(str(out)+ext+'.gz');dest.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(dest.read_bytes())==raw
for ext in ['.publication.json','.verified.json','.batches.ndjson']:shutil.copyfile(str(base)+ext,str(out)+ext)
p=pathlib.Path('docs/ai-rounds/ACTIVE.json');a=json.loads(p.read_text());assert a['round']==30 and a['status']=='in_progress';a.update(executions=n,checkpoint='partial_'+str(n)+'_verified_of3072_not_complete',checkpointAt=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat());a['developmentSeeds']['status']='in_progress_'+str(n)+'_of3072';p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
p=pathlib.Path('docs/ai-rounds/ROUND_030_20261015_1917.md');p.write_text(p.read_text()+'\n## 실행 중 체크포인트'+str(n)+'\n\n'+str(n)+'/3072실행·원자료/저널/publication 독립 검증 완료. 전역 기준/고정 소스/표본 불변, 전체 회차는 진행 중이다. 압축 원자료와 저널/publication/부분 verified/배치 기록을 cooperation-round-030-checkpoint'+str(n)+'.*에 보존했다.\n')
print(json.dumps({'executions':n,'checkpoint':str(out)},ensure_ascii=False))
