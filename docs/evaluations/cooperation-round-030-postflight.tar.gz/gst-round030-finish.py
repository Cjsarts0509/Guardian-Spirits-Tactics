import pathlib,json,datetime,hashlib
root=pathlib.Path('.');p=root/'docs/evaluations/cooperation-round-030-development-results.json';d=json.loads(p.read_text());v=d['summary'];assert not v['diagnosticGatePassed'];d['firstAttack']={'accepted':266,'attackFailure':0,'skills':{'advanced_attack':134,'attack':132}};d['residualWriterLocks']=0;d['archiveVerification']='passed_source_ref_7a8eb17';d['resumeProof']='cooperation-round-030-resume-proof.json';p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
md=root/'docs/ai-rounds/ROUND_030_20261015_1917.md';t=md.read_text().replace('<고정커밋>','7a8eb17df8692a4fc87e59c1810b0d9425d9a0ef');t+='''
## 완료 — 3,072실행·진단 기준 미달

개발142000–142031의4모드×3상대×4교환×control/single을32개96경기 배치로 실제 실행했다. 전체 종료3,072·새 미종료0·배치 실패/중복/저장 불일치/잔존 writer 잠금0이다. 관측용 원자료·저널·publication은 매 배치 검증했고768/1536/2304중간 자료도 별도 커밋했다. 완료 뒤 신규0재개에서 스냅샷/저널/publication3해시 불변과 전체 요약 복원을 확인했다. 압축 최종 자료도 불변 source-ref로 다시 독립 검증했다.

|모드|control 승률|한 번 추가 승률|차이pp|각 변형 실행|
|---|---:|---:|---:|---:|
|내전|68.2292%|67.9688%|−0.2604|384|
|태초|69.7917%|69.7917%|0|384|
|황야|65.6250%|66.4063%|+0.7813|384|
|트롤|61.1979%|61.4583%|+0.2604|384|
|전체|66.2109%|66.4063%|+0.1953|1,536|

전체 차이 시드95%구간[−0.2604,+0.5859]pp·사전 고정99%구간[−0.3906,+0.7161]pp. 개입266쌍/28시드로 최소 개입 조건은 충족했지만 전역99%하한>0을 통과하지 못했다. 비개입1,270쌍은 행동·결과 전체 동일이고,개입266쌍은 개입 전 엔진/자기 기억/뷰3해시·직접 수신 영수증·원래null·원래RNG동일을 검증했다. 개입 쌍 중6승패 개선/3악화/257동률이다. 모드/인물/후속 횟수로 후보를 사후 선택하지 않는다. main 비교가 없는 단일p1 진단이며 전체팀 정책 승률이나 운영 승격 증거가 아니다.

직접 영수증은gem.result184/inspect.result82. 추가 공격266건은 실제 허용·공격 실패0(일반132/상급134)이며 추가 대화0,잘못된 동맹/허위 보고/추가 공격의 아군·이름 오류/초반 공격 실패0이다. 이후 기존 정책의 전체 공격 실패는 별도 자원 지표에 남겨 두었으며 전 경기 공격 실패가0이라고 표시하지 않는다.

### 자원·전투 기회의 분리

아래는 개입 전 조건이 같은p1 대상 쌍에서 개입 이후 자기 영수증을 합산한 기술 지표다. 팀 전체 마나나 장래 자원의 순가치를 뜻하지 않으며 승률 개선으로 대체하지 않는다. 경기 조기 종료/생존 시간 변화도 합계에 영향을 준다.

|모드|개입쌍|추가 공격 최초 명목마나|control도5초내 같은 공격|control 같은 공격 없음|이후 자기 총 스킬 명목마나 control→single|진명 턴 보너스 control→single|수신 동맹 턴 보너스 control→single|
|---|---:|---:|---:|---:|---:|---:|---:|
|내전|54|2,700|14|1|10,360→9,735|1,840→1,680|2,590→2,420|
|태초|45|2,250|18|1|7,205→7,415|1,250→1,220|1,510→1,570|
|황야|89|4,450|24|8|15,625→15,615|2,780→2,730|5,200→5,050|
|트롤|78|3,900|33|4|15,845→15,760|2,580→2,460|5,070→4,910|

추가50마나 공격이 뒤의 공격을 대체하기도 하므로 최초 지출 합계를 경기 전체 추가 지출로 더하지 않는다. 황야/트롤의 공격 지연 감소와 자원 변화가 있어도 전역 승패 근거는 미달이다. 실제 최상급 공격은 기본 공격과 같은50마나이며 실패 사망 면제 차이가 있다(`skills/common.ts`, `engine/attack.ts`); 근거 없는 저비용 최상급 대체 후보도 만들지 않았다.

### 고정·재현·검증

- 평가 소스: `7a8eb17df8692a4fc87e59c1810b0d9425d9a0ef`.
- 운영 정책src는`c598fda20052bf46fc73d2b7affe0d0b5442159e`와byte동일,새 기본ON 없음.
- 정책 소스 맵 SHA256: `2ea5c58513401067080f126f0231a71b995101209e0fa6100e3cffbd1ac94961`.
- 설계/옵션 SHA256: `6c6cf2ec902a74111de2789bfdb4100b44143b7ab159bfdb87f736f3e881cea5`.
- 원자료 fingerprint: `a91f4ab8ee9f22355b65a336201cc9eeef4e9c30815dd3b053202d996860bc4e`.
- 622테스트(규칙547/서버75)·4패키지 타입·서버/클라이언트/Worker빌드·Python 감독기4회귀 통과. 사전 합성 fixture/단위 재생은 연구 누적에서 제외한다.
- 고정 소스 [CI](https://github.com/Cjsarts0509/Guardian-Spirits-Tactics/actions/runs/38720781717)·[브라우저](https://github.com/Cjsarts0509/Guardian-Spirits-Tactics/actions/runs/38720781843) 성공.

```bash
python tools/verify-check-pairs.py docs/evaluations/cooperation-round-030-development.json.gz --source-ref 7a8eb17df8692a4fc87e59c1810b0d9425d9a0ef --journal-path docs/evaluations/cooperation-round-030-development.journal.ndjson.gz
python tools/run-cooperative-generations.py 32 142000 /tmp/gst-round030.json 1 --source-ref 7a8eb17df8692a4fc87e59c1810b0d9425d9a0ef --profile check-pairs --lease-until 2026-10-15T20:02:46.502523+09:00
```

최종 압축 원자료/저널/publication/verified/32배치와全ソースSHAを`cooperation-round-030-development*`、新規0証明を`cooperation-round-030-resume-proof.json`に保存した。

누적 주자료25개/38,976실행/종료38,974·기존 제한 미종료2이다. 중단500·019미검증상한6·단위 fixture·중복 체크포인트는 제외한다. 사용 원장 비중복/독립121000·조건부143000 예약 침범0을 누적 감사에 기록했다. **판단: 후보 없음·기본OFF 유지·독립121000–121015 미사용·운영 승격0.** 실제 인간 참가 대전0·과거 물리적 저장 누락 환경 원인 미확정은 그대로 남는다.

다음031은 이 완료 개발 원자료에서 개입 이후 실제 공격 실패·보호 조건·기회비용의 증거를 제한 대조한다. 새 후보/추가 연구 표본을 먼저 늘리지 않고,저장된 자기 영수증만으로 확인되지 않는 실패 사례에 한해서 필요한 최소 결정론 재생을 별도 집계한다. 모드 선택이나 독립 표본 재튜닝은 하지 않는다.
'''.replace('최종 압축 원자료/저널/publication/verified/32배치와全ソースSHAを`cooperation-round-030-development*`、新規0証明を`cooperation-round-030-resume-proof.json`に保存した。','최종 압축 원자료/저널/publication/verified/32배치와 전체 소스SHA는 `cooperation-round-030-development*`, 신규0증명은 `cooperation-round-030-resume-proof.json`에 보존했다.')
md.write_text(t)
now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat();p=root/'docs/ai-rounds/ACTIVE.json';a=json.loads(p.read_text());a.update(status='completed',completedAt=now,executions=3072,checkpoint='complete_3072_archived_independently_verified_new0_resume',cumulativeExecutions=38976,decision='diagnostic_global99_lower_not_positive_no_candidate',nextAction='031 bounded own-receipt combat failure/opportunity audit of completed development, no new research seeds',unfinishedExecutions=0,cumulativeUnfinishedExecutions=2);a['developmentSeeds']['status']='used_completed_development_diagnostic_not_holdout';a['corpusAudit']={'datasets':25,'verifiedExecutions':38976,'terminatedGames':38974,'unfinishedExecutions':2,'seedRangesDisjoint':True,'reservedUnusedIntrusions':0,'path':'docs/evaluations/cooperation-round-030-cumulative-audit.json'};p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
msg='''**030 완료:** 새 개발142000–142031/3,072경기 전부 종료. 공개p1의 첫 직접 확인 후 추가 공격266쌍/28시드,control66.2109→single66.4063%·6개선3악화·시드99%구간[−0.3906,+0.7161]pp로 진단 기준 미달·후보 없음. 비개입1,270쌍 전체 동일·추가 공격 실패/안전/새 미종료/저장 불일치0·신규0재개3해시 불변.622테스트·타입·서버/클라이언트/Worker빌드·고정7a8eb17 CI/브라우저 성공. 누적38,976실행/종료38,974·기존 미종료2·독립121000미사용·143000조건부개발미사용. [030 기록](docs/ai-rounds/ROUND_030_20261015_1917.md). 즉시031은 실제 실패 영수증의 보호/불확실성 경계를 제한 대조하며 새 연구 없이 근거부터 확인한다.\n\n'''
for fn in ['HANDOFF.md','docs/AI_PROGRESS.md']:
 p=root/fn;prefix=msg if fn=='HANDOFF.md' else msg.replace('(docs/ai-rounds/','(ai-rounds/');p.write_text(prefix+p.read_text())
p=root/'docs/BOT_COOPERATIVE_INTEL.md';p.write_text('**최신030 완료·사용자18:18 연속 재개 지시 적용:** '+msg.replace('**030 완료:** ','').replace('(docs/ai-rounds/','(ai-rounds/')+'아래07시/12시 마감·비활성 기록은 당시 역사이며 최신 재개 지시가 대체한다. 현재 기본OFF·승격 기준과 정보 은닉 요구는 유지한다.\n\n'+p.read_text())
print({'completed':now,'cumulative':38976,'research':3072,'adoption':False})
