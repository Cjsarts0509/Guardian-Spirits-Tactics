import pathlib,json,gzip,hashlib,subprocess,copy
root=pathlib.Path('docs/evaluations/cooperation-round-033-preflight');base=pathlib.Path('/tmp/gst-round033-unit');original=json.loads(pathlib.Path(str(base)+'.json').read_bytes());header=pathlib.Path(str(base)+'.journal.ndjson').read_bytes().splitlines()[0];results=[];h=lambda b:hashlib.sha256(b).hexdigest()
for case in ['level2','forgedSender','directFacts']:
 d=copy.deepcopy(original);t=next(t for x in d['records'] for t in x['result']['reportedAttacks'])
 if case=='level2':t['level']=2
 elif case=='forgedSender':t['senders'][0]['event']['data']['from']='p999'
 else:t['knownName']=t['name']
 journal=header+b'\n'+b''.join(json.dumps(x,ensure_ascii=False,separators=(',',':')).encode()+b'\n' for x in d['records']);d['journalSha256']=h(journal);snapshot=json.dumps(d,ensure_ascii=False,separators=(',',':')).encode();pub={'version':2,'fingerprint':d['fingerprint'],'executions':d['executions'],'complete':d['complete'],'snapshotSHA256':h(snapshot),'journalSHA256':h(journal)}
 stem=root/('tamper-'+case);pathlib.Path(str(stem)+'.json.gz').write_bytes(gzip.compress(snapshot,mtime=0));pathlib.Path(str(stem)+'.journal.ndjson.gz').write_bytes(gzip.compress(journal,mtime=0));pathlib.Path(str(stem)+'.publication.json').write_text(json.dumps(pub,indent=2)+'\n')
 cmd=['python','tools/verify-claim-commitment.py',str(stem)+'.json.gz','--journal-path',str(stem)+'.journal.ndjson.gz'];r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode and 'AssertionError' in r.stderr,(case,r.stdout,r.stderr);(root/('tamper-'+case+'.log')).write_text(r.stdout+r.stderr);results.append({'case':case,'exitCode':r.returncode,'journalAndPublicationRehashed':True,'rawGzSHA256':h(pathlib.Path(str(stem)+'.json.gz').read_bytes()),'failedAssertion':r.stderr.splitlines()[-1]})
(root/'tamper-results.json').write_text(json.dumps(results,indent=2)+'\n');print(results)
