from pathlib import Path
import json,gzip,hashlib,shutil,subprocess,argparse
p=argparse.ArgumentParser();p.add_argument('phase',choices=['development','holdout']);a=p.parse_args()
base=Path('docs/evaluations/cooperation-round-032-'+a.phase);source='5db38453b1b4949eba727a9b21c9d3d0f28d6566';raw=Path('/tmp/gst-round032-'+a.phase+'.json');d=json.loads(raw.read_bytes());expected=1152 if a.phase=='development' else 2304;assert d['complete'] and d['executions']==expected
for p,suffix in [(raw,'.json.gz'),(raw.with_suffix('.journal.ndjson'),'.journal.ndjson.gz')]:Path(str(base)+suffix).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for ext in ['.publication.json','.batches.ndjson']:shutil.copy2(raw.with_suffix(ext),Path(str(base)+ext))
verified=subprocess.check_output(['python','tools/verify-claim-commitment.py',str(base)+'.json.gz','--source-ref',source,'--journal-path',str(base)+'.journal.ndjson.gz']);Path(str(base)+'.verified.json').write_bytes(verified)
result=Path('docs/evaluations/cooperation-round-032-'+a.phase+'-results.json')
subprocess.run(['python','tools/summarize-cooperative-development.py',str(base)+'.json.gz',str(base)+'.verified.json',str(result),'--source-ref',source],check=True)
m=json.loads(result.read_bytes());v=json.loads(verified);m.update(kind='completed-'+a.phase+'-summary',phase=a.phase,holdoutUsed=a.phase=='holdout',holdoutGatePassed=v['holdoutGatePassed'],tests=627,rulesTests=552,serverTests=75,builds='server_client_worker_passed',actualHumanMatches=0,batchFailures=0,duplicateExecutions=0,residualWriterLocks=len(list(Path(str(raw)+'.generations').glob('batch-*/data.json.store/WRITER.lock'))),terminated=expected-sum(x['unfinished'] for x in m['results'].values()),newResearchExecutions=expected,sourceCI='https://github.com/Cjsarts0509/Guardian-Spirits-Tactics/actions/runs/38725019788',sourceBrowser='https://github.com/Cjsarts0509/Guardian-Spirits-Tactics/actions/runs/38725019784')
m['files']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in base.parent.glob(base.name+'.*')};result.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'phase':a.phase,'developmentGate':m['developmentGatePassed'],'holdoutGate':m['holdoutGatePassed'],'reactions':m['checkReactionCount'],'pairedScores':m['pairedScores']}))

# Counts describe decisions, not independent wins or avoided deaths.
pairs={};episodes=set();blocked=0;games=0
for x in d['records']:
 f=x['result']['game']['fixture'];key=(x['mode'],x['style'],f['seed'],f['reversed'],f['currentSide']);pairs.setdefault(key,{})[x['variant']]=x['result']
 for t in x['result'].get('blockedGuesses',[]):
  blocked+=1;episodes.add((*key,t['player'],t['originalAction']['target'],t['originalAction']['name'],t['previousFailureAt']))
for z in pairs.values():
 c=z['avoidRepeatedFailedGuess'];b=z['control']
 if c['blockedGuesses']:games+=1
 else:assert c==b,'No blocked guess but policy results differ'
m.update(blockedGuessCalls=blocked,blockedGuessEpisodes=len(episodes),blockedGuessGames=games,nonBlockedEqualGames=len(pairs)-games,resourceByMode={v:{mode:{'attackFailures':sum(x['result']['resources']['attackFailures'] for x in d['records'] if x['variant']==v and x['mode']==mode),'skillNominalMana':sum(x['result']['resources']['acceptedSkillMana'] for x in d['records'] if x['variant']==v and x['mode']==mode)} for mode in ['civil_war','primordial','lidellut','troll']} for v in d['variants']})
result.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'blockedCalls':blocked,'blockedEpisodes':len(episodes),'blockedGames':games,'nonBlockedEqual':len(pairs)-games}))
