import pathlib,json,gzip,hashlib,subprocess,tarfile
root=pathlib.Path('/workspace/scratch/ec7ea2e0b6ba/Guardian-Spirits-Tactics');out=root/'docs/evaluations';base=pathlib.Path('/tmp/gst-round045-selfplay');source='cad80d2c843c16dd97104f5c844a0298e589f51d';prefix='cooperation-round-045-selfplay'
sha=lambda b:hashlib.sha256(b).hexdigest()
enc=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
paths=[base.with_suffix(x) for x in ['.json','.journal.ndjson','.publication.json']];before={p.name:sha(p.read_bytes()) for p in paths};d=json.loads(paths[0].read_bytes());assert d['complete'] and d['executions']==320
batches=[json.loads(l) for l in base.with_suffix('.batches.ndjson').read_text().splitlines()];assert len(batches)==8 and sum(b['fresh'] for b in batches)==320 and [b['total'] for b in batches]==list(range(40,321,40))
cmd=['python','tools/run-report-selfplay.py','80','151000',str(paths[0]),'1','--source-ref',source,'--lease-until','2026-10-18T07:16:00+09:00'];r=subprocess.run(cmd,cwd=root,capture_output=True,text=True);assert r.returncode==0,r.stderr
resume=json.loads(r.stdout.strip().splitlines()[-1]);assert resume['newGames']==0 and resume['unchanged'];assert before=={p.name:sha(p.read_bytes()) for p in paths}
for p,suffix in zip(paths,['.json.gz','.journal.ndjson.gz','.publication.json']):
 raw=p.read_bytes();(out/(prefix+suffix)).write_bytes(gzip.compress(raw,mtime=0) if suffix.endswith('.gz') else raw)
(out/(prefix+'.batches.ndjson')).write_bytes(base.with_suffix('.batches.ndjson').read_bytes());(out/(prefix+'.resume.json')).write_bytes(enc(resume))
verified=subprocess.check_output(['python','tools/verify-report-selfplay.py',str(out/(prefix+'.json.gz')),'--source-ref',source,'--journal-path',str(out/(prefix+'.journal.ndjson.gz'))],cwd=root);summary=json.loads(verified);(out/'cooperation-round-045-summary.json').write_bytes(verified)
repeat=subprocess.check_output(['python','tools/verify-report-selfplay.py',str(out/(prefix+'.json.gz')),'--source-ref',source,'--journal-path',str(out/(prefix+'.journal.ndjson.gz'))],cwd=root);assert repeat==verified
old=out/'cooperation-round-044-cumulative-audit.json';ledger=json.loads(old.read_bytes());used=set()
for x in ledger['primaryDatasets']:
 seeds=set(range(x['start'],x['start']+x['count']));assert not used&seeds;used|=seeds
assert not used&set(range(151000,151080));unfinished=sum(x['result']['game']['winner'] is None for x in d['records']);ledger['kind']='gst-round045-seed-ledger';ledger['previousLedgerSHA256']=sha(old.read_bytes());ledger['primaryDatasets'].append({'round':45,'start':151000,'count':80,'executions':320,'sourceRef':source,'snapshotSHA256':before['gst-round045-selfplay.json'],'journalSHA256':before['gst-round045-selfplay.journal.ndjson']});ledger['verifiedExecutions']=47680;ledger['terminated']=47678-unfinished;ledger['unfinished']=2+unfinished;ledger['newUnfinished']=unfinished;ledger['newResearchExecutions045']=320;ledger['reservedUnusedNext']=[152000,152079];assert sum(x['executions'] for x in ledger['primaryDatasets'])==47680;(out/'cooperation-round-045-cumulative-audit.json').write_bytes(enc(ledger))
with tarfile.open(out/'cooperation-round-045-preflight.tar.gz','w:gz') as tar:
 for name in ['gst-round045-validation','gst-round045-checks.py','gst-round045-finish.py','gst-round045-unit.log']:tar.add(pathlib.Path('/tmp')/name,arcname=name)
 for suffix in ['.json','.journal.ndjson','.publication.json']:tar.add('/tmp/gst-round045-synthetic-final'+suffix,arcname='synthetic/data'+suffix)
print(json.dumps({k:v for k,v in summary.items() if k!='firstDivergences'},ensure_ascii=False,indent=2))
