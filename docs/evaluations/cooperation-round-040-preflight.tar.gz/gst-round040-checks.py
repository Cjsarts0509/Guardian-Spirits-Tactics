import subprocess,pathlib,json,datetime
root=pathlib.Path('/workspace/scratch/dda69bfb36e1/Guardian-Spirits-Tactics');out=pathlib.Path('/tmp/gst-round040-validation');commands=[];out.mkdir(exist_ok=True)
for sub in ['packages/rules','apps/server']:
 commands.append((sub,['node','node_modules/vitest/vitest.mjs','run']))
for sub in ['packages/rules','packages/protocol','apps/server','apps/client']:
 commands.append((sub,['node',str(root/'node_modules/typescript/bin/tsc'),'-p','tsconfig.json','--noEmit']))
commands += [('apps/server',['node','node_modules/esbuild/bin/esbuild','src/index.ts','--bundle','--platform=node','--target=node22','--format=esm','--outfile=dist/index.js','--external:bufferutil','--external:utf-8-validate','--alias:@gst/rules=../../packages/rules/src/index.ts','--alias:@gst/protocol=../../packages/protocol/src/index.ts','--banner:js=import { createRequire } from "module"; const require = createRequire(import.meta.url);']),('apps/client',['node','node_modules/vite/bin/vite.js','build'])]
results=[]
for i,(sub,cmd) in enumerate(commands):
 r=subprocess.run(cmd,cwd=root/sub,capture_output=True,text=True);log=out/f'check-{i:02}.log';log.write_text(r.stdout+r.stderr);results.append({'cwd':sub,'command':cmd,'exitCode':r.returncode,'log':str(log)});print(i,sub,r.returncode,(r.stdout+r.stderr)[-200:],flush=True)
 if r.returncode:break
(out/'checks.json').write_text(json.dumps({'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'results':results},ensure_ascii=False,indent=2)+'\n')
raise SystemExit(any(x['exitCode'] for x in results))
