# 040 사전검사

최초 실제 엔진 회귀는 통과했으나 타입 검사에서 PlayerState에 없는 lives를 사용한 것을 발견했다(TS2551). 불필요한 targetLives 관측을 제거했다. 보호 실행 스킬과 횟수 차감에 실제 필요한 passive bodyguard 스킬을 구분해 hasSkill은 consume_bodyguard/kumarin_bodyguard로 관측한다. 실제 시전 뒤 보호 횟수2 및 보디가드 스킬 획득까지 회귀를 보강했다. 정책·엔진은 수정하지 않았다.

전체658테스트(규칙583/서버75),4패키지 타입,서버/클라이언트/Worker빌드 통과. 보강한 신규 회귀도 다시 통과했다.
