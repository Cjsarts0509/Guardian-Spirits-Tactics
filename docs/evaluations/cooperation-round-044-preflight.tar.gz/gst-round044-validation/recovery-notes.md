# 044 저장 공간 중단과 복구

원래 감독기 경로 /tmp/gst-round044-development/data.json, 소스2541ef036fba963e83f2cd4b089fc3ddf85735c8.
96/192/288의 세 배치가 각각 독립 검증·publication을 통과한 뒤, 네 번째 generation에 이전288의 export를 복사하던 중 ENOSPC가 발생했다. 네 번째 수집기는 시작되지 않았으며 기존288은 재검증됐다. 감독기 프로세스는 종료1을 반환했다.

원자료/저널/publication288을 /dev/shm/gst-round044-recovery/data.*에 복사하고 같은 불변 소스·후보·시드에서 최대9배치로 재개했다. 기존288의 키를 재사용해 건너뛰며 새 시드 예약/정책 수정/완료 경기 재실행은 없다. 마지막에 원본288prefix·12배치 신규 합1152·완료 신규0 재개를 확인한다.

이번043 재생 임시 JSON은 repo gzip과 cmp동일 확인 후 삭제했다. 044 중단 generation 디렉터리는 /tmp/gst-round044-interrupted-generations.tar.gz로 압축하고 tar --compare 성공 후 원본 중복 폴더만 정리했다. 완료038 generation 디렉터리도 WRITER잠금 부재와 완료1152publication/보존 repo원자료를 확인한 뒤 /tmp/gst-round038-generations-preserved.tar.gz로 압축·tar --compare하고 중복 폴더만 정리했다. 두 압축본에서 모두 복구 가능하며 연구 주원자료는 삭제하지 않았다.

디스크 쓰기 중 요약 스크립트 작성이4096바이트에서 끊겼다. 수집기/정책 소스와 무관한 미커밋 분석 파일이며, apply_patch로 완성 후 py_compile과 합성144 전체 분석을 통과했다. 최초 새 테스트의 root호출은 기존 테스트의 cwd 의존으로8개 skipped/1 suite ENOENT가 났고, 정식 패키지 cwd의 전체676테스트는 모두 통과했다.

최종 paired 요약에서 모든 첫 차이를 즉시 선택 변경으로 묶던 단정1개가 실패했다. 태초150007 허위 상대 정순2진영을 사후 재생하여 동일 공격에서도 RNG 이외 기억은 같고 RNG만 달라 후속 시각0.5초가 달라진1쌍을 분리했다. 정책/수치는 수정하지 않았다. 이식 진단 스크립트의 .ts import 타입 오류를 .js로 수정한 뒤 규칙 타입과 최종2경기/전체행동 원본 일치 재생을 통과했다. 초기 임시 스크립트2재생과 최종2재생은 중복/진단이며 연구 누적에서 모두 제외한다.
