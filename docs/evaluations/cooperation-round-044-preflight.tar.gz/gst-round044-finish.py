import pathlib,json,gzip,hashlib,subprocess,tarfile
root=pathlib.Path('/workspace/scratch/dda69bfb36e1/Guardian-Spirits-Tactics');out=root/'docs/evaluations';base=pathlib.Path('/dev/shm/gst-round044-recovery/data');validation=pathlib.Path('/tmp/gst-round044-validation');source='2541ef036fba963e83f2cd4b089fc3ddf85735c8'
sha=lambda b:hashlib.sha256(b).hexdigest()
enc=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
paths=[base.with_suffix(x) for x in ['.json','.journal.ndjson','.publication.json']];before={p.name:sha(p.read_bytes()) for p in paths}
d=json.loads(paths[0].read_bytes());assert d['complete'] and d['executions']==1152
previous=json.loads(pathlib.Path('/tmp/gst-round044-development/data.json').read_bytes());assert previous['executions']==288 and previous['records']==d['records'][:288] and previous['fingerprint']==d['fingerprint']
logs=[pathlib.Path('/tmp/gst-round044-development/data.batches.ndjson'),base.with_suffix('.batches.ndjson')];batches=[json.loads(l) for p in logs for l in p.read_text().splitlines()];assert len(batches)==12 and [x['executions'] for x in batches]==list(range(96,1153,96)) and sum(x['newGames'] for x in batches)==1152 and all(x['publicationVerified'] for x in batches)
cmd=['python','tools/run-cooperative-generations.py','8','150000',str(paths[0]),'1','--source-ref',source,'--candidate','reportedSupreme']
r=subprocess.run(cmd,cwd=root,capture_output=True,text=True);assert r.returncode==0,r.stderr;resume=json.loads(r.stdout);assert resume['newGames']==0 and resume['complete'];after={p.name:sha(p.read_bytes()) for p in paths};assert before==after
prefix='cooperation-round-044-development'
for p,suffix in zip(paths,['.json.gz','.journal.ndjson.gz','.publication.json']):
 raw=p.read_bytes();(out/(prefix+suffix)).write_bytes(gzip.compress(raw,mtime=0) if suffix.endswith('.gz') else raw)
(out/(prefix+'.batches.ndjson')).write_text(''.join(json.dumps(x)+'\n' for x in batches))
resume.update({'hashesBefore':before,'hashesAfter':after,'hashesUnchanged':True,'recovered288PrefixExact':True,'initial288SHA256':sha(pathlib.Path('/tmp/gst-round044-development/data.json').read_bytes()),'newGamesIn12Batches':1152,'interruption':'ENOSPC before fourth collector started','canonicalDuplicatesArchived':True});(out/(prefix+'.resume.json')).write_bytes(enc(resume))
verified=subprocess.check_output(['python','tools/verify-claim-commitment.py',str(out/(prefix+'.json.gz')),'--source-ref',source,'--journal-path',str(out/(prefix+'.journal.ndjson.gz'))],cwd=root);(out/(prefix+'.verified.json')).write_bytes(verified);v=json.loads(verified)
behavior=subprocess.check_output(['python','tools/summarize-supreme-development.py',str(out/(prefix+'.json.gz')),str(out/(prefix+'.verified.json'))],cwd=root);(out/'cooperation-round-044-behavior.json').write_bytes(behavior)
repeat=subprocess.check_output(['python','tools/summarize-supreme-development.py',str(out/(prefix+'.json.gz')),str(out/(prefix+'.verified.json'))],cwd=root);assert repeat==behavior
old=out/'cooperation-round-039-cumulative-audit.json';ledger=json.loads(old.read_bytes());used=[range(x['start'],x['start']+x['count']) for x in ledger['primaryDatasets']];assert all(not set(range(150000,150008))&set(x) for x in used)
unfinished=sum(x['result']['game']['winner'] is None for x in d['records']);ledger['kind']='gst-round044-seed-ledger';ledger['previousLedgerSHA256']=sha(old.read_bytes());ledger['primaryDatasets'].append({'round':44,'start':150000,'count':8,'executions':1152,'sourceRef':source,'snapshotSHA256':before['data.json'],'journalSHA256':before['data.journal.ndjson']});ledger['verifiedExecutions']=47360;ledger['terminated']=47358-unfinished;ledger['unfinished']=2+unfinished;ledger['newUnfinished']=unfinished;ledger['newResearchExecutions044']=1152;ledger['reservedUnusedNext']=[151000,151079];ledger['remainingUnused150000']=[150008,150079];ledger['resumeHashesUnchanged']=True;assert sum(x['executions'] for x in ledger['primaryDatasets'])==47360;(out/'cooperation-round-044-cumulative-audit.json').write_bytes(enc(ledger))
with tarfile.open(out/'cooperation-round-044-preflight.tar.gz','w:gz') as tar:
 tar.add(validation,arcname='validation');tar.add('/tmp/gst-round044-checks.py',arcname='checks.py');tar.add(__file__,arcname='finish.py')
 for name in ['data.json','data.journal.ndjson','data.publication.json']:tar.add(pathlib.Path('/tmp/gst-round044-synthetic')/name,arcname='synthetic/'+name)
print(json.dumps({'executions':1152,'unfinished':unfinished,'cumulative':47360,'behavior':{k:v for k,v in json.loads(behavior).items() if k not in ['strata','actualReportAttacks','limitations']},'contrasts':v['contrasts']},ensure_ascii=False,indent=2))
